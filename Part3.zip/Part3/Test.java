/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.test;

/**
 *
 * @author RC_Student_lab
 */
public class Test {

    public static void main(String[] args) {
        System.out.println("Hello World!");
               JOptionPane.showMessageDialog(null,"Welcome to Quick-change!");
        boolean running = true;
        while(running){
            int choice = displayMenu();
            switch(choice){
                case 1:
                    JOptionPane.showMessageDialog(null,"Send messsage");
                    break;
                case 2:
                    JOptionPane.showMessageDialog(null,"Coming Soon");
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null,"Thank you for using Quick-change , Goodbye!");
                    
                    running = false;
                    break;
                default:JOptionPane.showMessageDialog(null,"Invalid option. Please try again.");
                
            }
        }
    }
    private static int displayMenu(){
        String[]opions ={"Send messages","Coming soon","Quit"};
        int choice = JOptionPane.showOptionDialog(
                null,
                "Please selsect an option:",
                "Quick-change MENU",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]);
        return choice + 1;
      
                
    }
    private static void handleMessage(){
        int messageCount = 0;
        boolean validInput = false;
        while(!validInput){
            String input = JOptionPane.showInputDialog("How many messages would you like to enter ?");
            if(input == null){
                return;
            }
            try{
                messageCount = Integer.parseInt(input);
                if(messageCount>0){
                    validInput =true;
                }
                else{
                    JOptionPane.showMessageDialog(null,"Please enter a positive number.");
                }
            }
            catch(NumberFormateException e){
                JOptionPane.showMessageDialog(null,"Please enter a valid number");
            }
        }
        StringBuilder resultMessage = new StringBuilder("Message recieved:\n\n");
        for(int i = 0; i<messageCount; i++){
            String message = JOptionPane.showInputDialog("Enter message " +(i + 1) +":");
            if(message == null){
                message = "[Message canceled]";
            }
            resultMessage.append(i+1).append(".\"").append(message).append("\"\n");
        }
        JOptionPane.showMessageDialog(null,resultMessage.toString()+ "\nAll messages sent successfully!");
    }
    private static int messagesSent=0;
    private static List<Message> storedMessages = new ArrayList<>();
     
    boolean running = true;
    while(running){
    String[]options ={"Create new message","View stored messages","Delete a message","Exit"};
    int choice = JOptionPane.showOptionDialog(
            null,
            "Welcome to the message System!\nPlease choose an option:",
            "MESSAGE SYSTEM",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.INFORMATION_MESSAGE,
            null,
            options,
            options[0]);
    
    switch(choice){
        case 0:
            createMessage();
            break;
        case 1:
            viewStoredMessage();
            break;
        case 2:
            deleteMessage();
            break;
        case 3:
        case JOptionPane.CLOSED_OPTION:
            running = false ;
            JOptionPane.showMessageDialog(null,"Exiting system.Goodbye.",JOptionPane.INFORMATION_MESSAGE messagesSent);
            break;
        default:
            JOptionPane.showMessageDialog(null,"Invalid option.Please try again.","Error",JOptionPane.ERROR_MESSAGE);
      
    }
            
    }
    String recipientNumber;
      while (true){
        recipientNumber = JOptionPane.showInputDialog(
        null,"Enter recipient's phone number(max 10 characters ):",
                "Recipient Phone Number",
                JOptionPane.Question_MESSAGE);
        if(recipientNumber == null){
            return;
          
      }
        recipientNumber = recipientNumber.trim();
        if(recipientNumber.length()<=10 && recipientNumber.matches("\\+?\\d+")){
            break;
            
        }else{
            JOptionPane.showMessageDialog(null,"Invalid phone number.Please ensure it is not more that 10 digits.","Invalid phone number.",JOptionPane.ERROR_MESSAGE);
            
        }

    }
      String messageContent = JOptionPane.showInputDialog(null,"Enter your message(max 250 characters):","Message Content",JOptionPane.QUESTION_MESSAGE);
      if(messageContent.length()>250){
          JOptionPane.showMessageDialog(null,"Please enter a message of less than 250 characters.","Message too long",JOptionPane.ERROR_MESSAGE);
           return;
      }
      String messageId = generateMessageId ();
      String messageHash = generateMessageHash(messageId,messageContent);
      Message message= new Message(messageId, ++messageSent, recipientNumber,messageContent,messageHash);
      String[]actionOptions ={"Send message", "Disregard message","Store message to send later"};
      int action = JOptionPane.showOptionDialog(null,"Message creatd!\nWhat would you like to do?", "Message Created", JOptionPane.DEFAULT_OPTION,JOptionPane.QUESTION_MESSAGE,null, actionOptions,actionOptions[0]);
      
     switch (action){
         case 0:
             JOptionPane.showMessageDialog(null,"Message sent!\n\nMessage details:\n" +message.toString(),"Message Sent",JOptionPane.INFORMATION_MESSAGE);
             break;
         case 1:
             JOptionPane.showMessageDialog(null,"Message disregarded","Message Disregarded",JOptionPane.INFORMATION_MESSAGE);
             
         case 2:
             storedMessage.add(message);
             JOptionPane.showMessageDialog(null,"Message stored for later.","Message Stored",JOptionPane.INFORMATION_MESSAGE);
             break;
     }
             if(storedMessage.isEmpty()){
                 JOptionPane.showMessageDialog(null,"No stored messages." ,"No Messages",JOptionPane.INFORMATION_MESSAGE);
                 return;
             }
             StringBuilder messageList = new StringBuilder("STORED MESSAGES:\n\n");
             for(int i = 0;i<storedMessages.size();i++){
    messageList.append((i+1)).append(".Message ID:")
            .append(storedMessages.get(i).getRecipient())
            .append("\n  To:").append(storedMessage.get(i).getRecipient())
            .append("\n  Content:").append(storedMessage.get(i).getContent())
            .append("\n\n");
            
    }
             int sendChoice = JOptionPane.showConfirmDialog(null,message);
    }
}
