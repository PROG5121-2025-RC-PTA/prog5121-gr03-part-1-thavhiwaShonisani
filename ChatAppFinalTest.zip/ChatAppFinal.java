/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chatappfinal;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author RC_Student_lab
 */
public class ChatAppFinal {
    private static List<User> users = new ArrayList<>();
    private static User currentUser = null;
//Menu for registration
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null,"Welcome to Quickchat");
        while (true) {
            String choice = JOptionPane.showInputDialog(
                "Main Menu:\n1. Register\n2. Login\n3. Quit"
            );

            if (choice == null) continue;

            switch (choice) {
                case "1":
                    registerUser();
                    break;
                case "2":
                    loginUser();
                    if (currentUser != null) mainMenu();
                    break;
                case "3":
                    System.exit(0);
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option.");
            }
        }
    }
//Registering the user information
    private static void registerUser() {
        while (true) {
            String username = JOptionPane.showInputDialog("Enter a new username:");
            if (username == null || username.trim().isEmpty()) continue;

            if (findUser(username) != null) {
                JOptionPane.showMessageDialog(null, "Username already exists. Try a different one.");
                continue;
            }

            String phoneNumber = JOptionPane.showInputDialog("Enter phone number:");
            if (phoneNumber == null || phoneNumber.trim().isEmpty()) continue;

            String password = JOptionPane.showInputDialog("Create a password:");
            if (password == null) continue;

            User newUser = new User(username, phoneNumber, password);
            users.add(newUser);
            JOptionPane.showMessageDialog(null, "Account created for " + username + ". Returning to main menu.");
            break;
        }
    }
//User can log in after successful registration
    private static void loginUser() {
        while (true) {
            String username = JOptionPane.showInputDialog("Enter your username:");
            if (username == null || username.trim().isEmpty()) return;

            User foundUser = findUser(username);
            if (foundUser == null) {
                JOptionPane.showMessageDialog(null, "User not found.");
                return;
            }

            String password = JOptionPane.showInputDialog("Enter your password:");
            if (password == null || !password.equals(foundUser.getPassword())) {
                JOptionPane.showMessageDialog(null, "Incorrect password.");
                return;
            }

            currentUser = foundUser;
            JOptionPane.showMessageDialog(null, "Login successful. Welcome, " + username + "!");
            break;
        }
    }
//Finds the users login information
    private static User findUser(String username) {
        for (User u : users) {
            if (u.getUsername().equals(username)) return u;
        }
        return null;
    }
//User options for interaction
    private static void mainMenu() {
        while (true) {
            String choice = JOptionPane.showInputDialog(
                "Hello, " + currentUser.getUsername() +
                "!\n1. Send Message\n2. Show Recently Sent Messages\n3. Quit"
            );
            if (choice == null) continue;

            switch (choice) {
                case "1":
                    int max = getMaxMessages();
                    for (int i = 0; i < max; i++) {
                        sendMessage();
                    }
                    break;
                case "2":
                    JOptionPane.showMessageDialog(null, "Coming Soon");
                    break;
                case "3":
                    currentUser = null;
                    return;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice.");
            }
        }
    }
//Ask the user how many meesages they would like to send
    private static int getMaxMessages() {
        int max = 0;
        while (max <= 0) {
            try {
                String input = JOptionPane.showInputDialog("How many messages would you like to send?");
                if (input == null) return 0;
                max = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Please enter a valid number.");
            }
        }
        return max;
    }
//Send message
    private static void sendMessage() {
        String recipientNumber = JOptionPane.showInputDialog("Enter recipient's phone number:");
        int recipientCheck = Message.checkRecipientCell(recipientNumber);

        if (recipientCheck == 1) {
            JOptionPane.showMessageDialog(null, "Phone number is too long.");
            return;
        } else if (recipientCheck == 2) {
            JOptionPane.showMessageDialog(null, "Phone number format is invalid.");
            return;
        }

        String content = JOptionPane.showInputDialog("Enter message:");
        if (content == null || content.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Message cannot be empty.");
            return;
        }

        if (content.length() > 250) {
            JOptionPane.showMessageDialog(null, "Please enter a message of less than 50 characters.");
            return;
        }

        Message msg = new Message(recipientNumber, content);
        msg.SentMessage();
    }
}
