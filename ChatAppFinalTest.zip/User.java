/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatappfinal;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author RC_Student_lab
 */
class User {
    private String username; // stores the user's name
    private String phoneNumber; // stores the user's phone number
    private String password; // stores the user's password
    private List<Message> messages; // list of messages this user has created

    // Default constructor initializes empty message list
    public User() {
        messages = new ArrayList<>();
    }

    // Constructor used when registering a new user
    public User(String username, String phoneNumber, String password) {
        this.username = username;
        this.phoneNumber = phoneNumber;
        this.password = password;
        this.messages = new ArrayList<>();
    }

    // Adds a message to the user's message list
    public void addMessage(Message msg) {
        messages.add(msg);
    }

    public List<Message> getMessages() {
        return messages;
    }

    public String getUsername() {
        return username;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getPassword() {
        return password;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setMessages(List<Message> messages) {
        this.messages = messages;
    }

   
    // Check if the password is atleast 8 characters also has a uppercase letter, a digit, and a special character
    public boolean isPasswordValid() {
        if (password == null || password.length() < 8) return false;

        boolean hasUpper = false;
        boolean hasDigit = false;
        boolean hasSpecial = false;

        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasUpper = true;
            else if (Character.isDigit(c)) hasDigit = true;
            else if (!Character.isLetterOrDigit(c)) hasSpecial = true;
        }

        return hasUpper && hasDigit && hasSpecial;
    }
}
