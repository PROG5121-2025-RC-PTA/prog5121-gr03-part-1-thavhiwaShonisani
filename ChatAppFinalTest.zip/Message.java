/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatappfinal;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author RC_Student_lab
 */
public class Message {
    
   // List to track all sent message 
    private static List<String> sentMessages = new ArrayList<>();

    // Counter for total messages sent
    private static int totalMessages = 0;

    // File to store messages in JSON format (if used in future)
    private static final String MESSAGE_FILE = "messages.json";

    // Message properties
    private String messageID;
    private String recipientCell;
    private String content;

    // Constructor initializes recipient, content, and generates message ID
    public Message(String recipientCell, String content) {
        this.messageID = generateMessageID();
        this.recipientCell = recipientCell;
        this.content = content;
    }

    // Generates a random 10-digit message ID
    private String generateMessageID() {
        Random rand = new Random();
        long number = 1000000000L + (long)(rand.nextDouble() * 9000000000L);
        return Long.toString(number);
    }

    // Validates recipient number based on length and digit-only format
    public static int checkRecipientCell(String number) {
        if (number.length() > 13) {
            return 1; // Too long
        }
        if (!number.matches("^\\+?\\d+")) {
            return 2; // Invalid format
        }
        return 0; // Valid
    }

    // Constructs a hash string 
    
    public String createMessageHash() {
        String[] words = content.trim().split("\\s+");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;
        return (messageID.substring(0, 2) + ":" + totalMessages + " " + firstWord + lastWord).toUpperCase();
    }

    // Increments the message counter and displays the message hash to the user
    public String SentMessage() {
        totalMessages++;
        String hash = createMessageHash();
        JOptionPane.showMessageDialog(null, "Message sent");
        JOptionPane.showMessageDialog(null, hash);
        return hash;
    }

    // Getter for message ID
    public String getMessageID() {
        return messageID;
    }

    // Getter for recipient phone number
    public String getRecipientCell() {
        return recipientCell;
    }

    // Getter for message content
    public String getContent() {
        return content;
    }
} 